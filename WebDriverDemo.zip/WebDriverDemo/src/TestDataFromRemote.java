import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;


public class TestDataFromRemote {
	
	private String host;
	private Integer port;
	private String user;
	private String password;
	
	
	public TestDataFromRemote(String host, Integer port, String user, String password) {
		this.host = host;
		this.port = port;
		this.user = user;
		this.password = password;
	}


	public void upload(String fileName, String remoteDir) {

		FileInputStream fis = null;
		connect();
		try {
			// Change to output directory
			sftpChannel.cd(remoteDir);

			// Upload file
			File file = new File(fileName);
			fis = new FileInputStream(file);
			sftpChannel.put(fis, file.getName());

			fis.close();
			System.out.println("File uploaded successfully - "+ file.getAbsolutePath());

		} catch (Exception e) {
			e.printStackTrace();
		}
		disconnect();
	}
	
	

	public static void main(String[] args) {
		
		
		String localPath = "D:\\kajol\\TestData";
		String remotePath = "C:\\MGS_TestData";
		
		TestDataFromRemote ftp = new TestDataFromRemote("10.115.3.63", 1402, "bluemesa", "password1234$");
		
		ftp.upload(localPath+"thunderstruck.testdata", remotePath);
		
		

	}

}