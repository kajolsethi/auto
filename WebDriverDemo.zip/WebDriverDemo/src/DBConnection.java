import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;



public class DBConnection {

public static void main(String[] args) throws Exception {

// TODO Auto-generated method stub

	String serverName;
	String User = null;
	String password;
	String databaseUrl;
	String dataBaseName;
	String port;
	String serverIp;

Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//jdbc:sqlserver://"+serverIp+":"+port+";DatabaseName="+dataBaseName
Connection con = DriverManager.getConnection("jdbc:sqlserver://10.247.208.68:1402;DatabaseName=casino", "sa", "!@#$%A1");
Statement sqlStatement = con.createStatement();


String usertype;
String query=
"IF NOT EXISTS(SELECT UserID FROM dbo.tb_UserAccount WHERE LoginName = '"+User+"')"+
"BEGIN "+
"DECLARE "+ 
" @rServerID int"+
", @rLoginName char(20)"+
", @rPassword char(20)"+
", @rBalance int"+
", @rIdentifierOut char(36)"+
", @rUserType int"+
", @iCount int"+
", @cLoginName char(20)"+
", @MachineIdentifier int"+
", @Currency int"+ 



" exec sp_RegisterNewUser @ServerID = 5001, "+
"@Currency = '17',"+
"@UserType = '0', "+
"@LoginName = 'amd',"+
"@Password ='test', "+
"@Email ='cartman@southpark.com', "+
"@FN ='Eric', "+
"@LN ='Cartman',"+
" @WrkTel ='5698659', "+
"@HomeTel ='4464654', "+
"@Fax ='4646666',"+
"@Addr1 ='25 South Park Street', "+
" @Addr2 ='South Park', "+
"@City ='South Park',"+
"@Country ='USA', "+
"@Province ='Colarado', "+
"@Zip ='1234',"+
"@IDNumber ='6901205121085', "+ 
"@Occupation ='Scholar',"+
"@Sex ='M', "+
"@DOB ='1969/01/20', "+
"@Alias ='Fat boy',"+
"@IdentifierIn =null,"+
"@EventID =29, "+
"@ModuleID =24, "+
"@ChangeAmt =100000,"+
"@CreditLimit =0,"+
"@MachineIdentifier=0,"+
"@HDIdentifier =null,"+
"@Creator = 1, "+
"@IdentifierOut =@rIdentifierOut output"+
" END";


ResultSet resSet = sqlStatement.executeQuery(query);


    System.out.println(resSet.getString("player inserted"));
    
    sqlStatement.close();
    con.close();
   
//jdbc:sqlserver://ipAddress:portNumber/dbName
}


}

