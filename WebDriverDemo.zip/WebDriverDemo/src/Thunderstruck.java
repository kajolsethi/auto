import java.awt.AWTException;
import java.awt.Robot;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.firefox.*;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

public class Thunderstruck {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\ks48496.ZENDER\\Desktop\\Automation\\Assignment\\Framework\\BrowserDriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://mobilewebserver9-mobiletesting14.installprogram.eu/Lobby/en/IslandParadise/games/5reelslots");
		// TODO Auto-generated method stub
		driver.manage().window().maximize();
		//WebDriverWait wait=new WebDriverWait(driver, 2000); 
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		WebElement game = driver.findElement(By.id("thunderstruckDesktop"));
		game.click();
		driver.findElement(By.name("username")).sendKeys("kajols");
		driver.findElement(By.name("password")).sendKeys("test");
		
		By by = By.xpath("//span[text()='Login']");
		WebElement login = driver.findElement(By.xpath("//span[text()='Login']"));
		login.click();
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
		//By by1 = By.xpath("//span[text()='txtSpin']");
		WebElement spin = driver.findElement(By.xpath("//*[@id='txtSpin']"));
		spin.click();
	}
}
		
		    
		

				
		
		//Actions actions = new Actions(driver);

		/*Robot robot = null;
		try {
			robot = new Robot();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

		//robot.mouseMove(1366,768);

		//Actions builder = new Actions(driver);   
		//builder.moveToElement(, 10, 25).click().build().perform();

		//robot.mouseMove(287,1063);

		//actions.click().build().perform();
		
		//WebElement spin = driver.findElement(By.name("Spin"));
		/*Point point = spin.getLocation();
		
		int NumberX = point.getX();
		int NumberY = point.getY();*/
		
		//actions.moveToElement(spin,1039 , 611).click().build().perform();
		

	


